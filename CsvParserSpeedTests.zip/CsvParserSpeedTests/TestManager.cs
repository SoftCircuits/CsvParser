﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CsvParserSpeedTests
{
    public class TestManager
    {
        // List of test CSV files and corresponding data type
        static List<(string file, Type type)> CsvFiles = new List<(string file, Type type)>
        {
            ("Test_01", typeof(C01)),
            ("Test_02", typeof(C02)),
            ("Test_03", typeof(C03)),
            ("Test_04", typeof(C04)),
        };

        private string CsvPath;

        /// <summary>
        /// Test results
        /// </summary>
        public List<TestResults> Results { get; set; }

        public TestManager(string csvPath)
        {
            CsvPath = csvPath;
            Results = new List<TestResults>();
        }

        public void Go()
        {
            Results.Clear();

            // Get all types that implement ITest
            var types = AppDomain.CurrentDomain.GetAssemblies().SelectMany(x => x.GetTypes())
                .Where(x => typeof(ITest).IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract);

            // Run tests on each test type
            foreach (Type type in types)
            {
                // Create instance of this test type
                ITest test = (ITest)Activator.CreateInstance(type);

                TestResults typeResults = new TestResults
                {
                    Name = test.Name,
                    Results = new List<TestResult>()
                };

                // Run test for each file
                foreach ((string, Type) csvFile in CsvFiles)
                {
                    // Get filenames
                    string inFile = Path.Combine(CsvPath, $"{csvFile.Item1}.csv");
                    string outFile = $"{inFile}_Out.csv";
                    File.Delete(outFile);

                    // Construct generic method for this file's data type
                    MethodInfo info = type.GetMethod("RunTest");
                    info = info.MakeGenericMethod(csvFile.Item2);

                    // Run test
                    Stopwatch watch = new Stopwatch();
                    watch.Start();
                    info.Invoke(test, new[] { inFile, outFile });
                    watch.Stop();

                    // Store results
                    typeResults.Results.Add(new TestResult
                    {
                        Name = csvFile.Item1,
                        Milliseconds = watch.ElapsedMilliseconds
                    });
                }

                // Add these results to results list
                Results.Add(typeResults);
            }
        }
    }
}
