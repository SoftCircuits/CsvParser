﻿using System;

namespace CsvParserSpeedTests
{
    class Program
    {
        // Location of CSV files
        const string CsvPath = @"D:\Users\Jonathan\source\repos\CsvParserSpeedTests\CSV Files";

        static void Main(string[] args)
        {
            // Run tests
            TestManager manager = new TestManager(CsvPath);
            manager.Go();

            // Display results
            bool first = true;
            foreach (TestResults results in manager.Results)
            {
                if (first)
                    first = false;
                else
                    Console.WriteLine();

                Console.WriteLine(results.Name);
                foreach (TestResult result in results.Results)
                    Console.WriteLine($"  {result.Name}.csv : {result.Milliseconds}ms");

                Console.WriteLine($"Total Time: {results.TotalMilliseconds}ms");
            }
            Console.ReadKey();
        }
    }
}
