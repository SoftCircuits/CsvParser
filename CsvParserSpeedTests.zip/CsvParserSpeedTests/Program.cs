﻿using System;
using System.Diagnostics;
using System.IO;

namespace CsvParserSpeedTests
{
    class Program
    {
        // Path to CSV test files (relative to EXE path)
        const string CsvPath = @"..\..\..\..\CSV Files";

        static void Main(string[] args)
        {
            Debug.Assert(Directory.Exists(CsvPath));

            // Run tests
            TestManager manager = new TestManager(CsvPath);
            manager.Run();

            // Display results
            bool first = true;
            foreach (TestResults results in manager.Results)
            {
                if (first)
                    first = false;
                else
                    Console.WriteLine();

                Console.WriteLine(results.Name);
                foreach (TestResult result in results.Results)
                    Console.WriteLine($"  {result.Name}.csv : {result.Milliseconds}ms");

                Console.WriteLine($"Total Time: {results.TotalMilliseconds}ms");
            }
            Console.ReadKey();
        }
    }
}
