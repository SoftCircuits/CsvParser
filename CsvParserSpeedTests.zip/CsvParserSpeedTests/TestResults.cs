﻿using System.Collections.Generic;
using System.Linq;

namespace CsvParserSpeedTests
{
    /// <summary>
    /// Represents test results for a single ITest provider and test file.
    /// </summary>
    public class TestResult
    {
        public string Name { get; set; }
        public long Milliseconds { get; set; }
    }

    /// <summary>
    /// Represents all test results for a single ITest provider.
    /// </summary>
    public class TestResults
    {
        public string Name { get; set; }
        public List<TestResult> Results { get; set; }

        public long TotalMilliseconds => Results.Sum(r => r.Milliseconds);
    }
}
