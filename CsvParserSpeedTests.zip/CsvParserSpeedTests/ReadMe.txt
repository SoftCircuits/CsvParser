﻿This application was written to test and compare different CSV file mapper libraries.

To add a new test, create the ITest-derived test class in the Tests folder. The program
will automatically find and run all ITest classes.

Jonathan Wood
https://www.nuget.org/profiles/SoftCircuits
