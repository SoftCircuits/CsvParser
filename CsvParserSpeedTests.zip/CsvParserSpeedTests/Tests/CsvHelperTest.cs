﻿using CsvHelper;
using System.Globalization;
using System.IO;

namespace CsvParserSpeedTests
{
    public class CsvHelperTest : ITest
    {
        public string Name => "CsvHelper";

        public void RunTest<T>(string inPath, string outPath) where T : class, new()
        {
            using (StreamReader inStream = new StreamReader(inPath))
            using (StreamWriter outStream = new StreamWriter(outPath))
            using (CsvReader reader = new CsvReader(inStream, CultureInfo.InvariantCulture))
            using (CsvWriter writer = new CsvWriter(outStream, CultureInfo.InvariantCulture))
            {
                writer.WriteHeader<T>();

                foreach (var item in reader.GetRecords<T>())
                {
                    writer.WriteRecord<T>(item);
                }
            }
        }
    }
}
