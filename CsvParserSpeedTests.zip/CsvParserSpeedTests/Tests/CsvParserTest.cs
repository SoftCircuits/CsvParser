﻿using SoftCircuits.CsvParser;

namespace CsvParserSpeedTests
{
    public class CsvParserTest : ITest
    {
        public string Name => "SoftCircuits.CsvParser";

        public void RunTest<T>(string inPath, string outPath) where T : class, new()
        {
            using CsvReader<T> reader = new CsvReader<T>(inPath);
            using CsvWriter<T> writer = new CsvWriter<T>(outPath);

            reader.ReadHeaders(true);
            writer.WriteHeaders();

            while (reader.Read(out T item))
            {
                writer.Write(item);
            }
        }
    }
}
