﻿using SoftCircuits.CsvParser;

namespace CsvParserSpeedTests
{
    public class CsvParserTest : ITest
    {
        public string Name => "SoftCircuits.CsvParser";

        public void RunTest<T>(string inPath, string outPath) where T : class, new()
        {
            using (CsvDataReader<T> reader = new CsvDataReader<T>(inPath))
            using (CsvDataWriter<T> writer = new CsvDataWriter<T>(outPath))
            {
                reader.ReadHeaders(true);
                writer.WriteHeaders();

                while (reader.Read(out T item))
                {
                    writer.Write(item);
                }
            }
        }
    }
}
