﻿namespace CsvParserSpeedTests
{
    /// <summary>
    /// Interface for all test providers.
    /// </summary>
    public interface ITest
    {
        /// <summary>
        /// Returns the name/description of this test.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Runs this test.
        /// </summary>
        /// <typeparam name="T">Type to be mapped to this CSV file.</typeparam>
        /// <param name="inPath">Full path of input CSV file.</param>
        /// <param name="outPath">Full path of output file.</param>
        void RunTest<T>(string inPath, string outPath) where T : class, new();
    }
}
