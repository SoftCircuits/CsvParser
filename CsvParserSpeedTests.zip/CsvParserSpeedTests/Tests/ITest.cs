﻿namespace CsvParserSpeedTests
{
    /// <summary>
    /// Interface for all test providers.
    /// </summary>
    public interface ITest
    {
        string Name { get; }
        void RunTest<T>(string inPath, string outPath) where T : class, new();
    }
}
